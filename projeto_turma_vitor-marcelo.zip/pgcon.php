<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contato - Shows.Com</title>
    <link rel="stylesheet" href="css/pgcon.css">
</head>
<body>
    <!-- Cabeçalho -->
    <header class="header">
        <h1>Contato - Shows.Com</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="pgp.php">Shows</a></li>
                <li><a href="pgcon.php">Contato</a></li>
                <li><a href="pglog.php">Login</a></li>
                <li><a href="pgsob.php">Sobre</a></li>
            </ul>
        </nav>
    </header>

    <!-- Seção de Contato -->
    <section class="contact-section">
        <h2>Entre em Contato</h2>
        <p>Para mais informações, entre em contato com nossos responsáveis:</p>
        
        <!-- Lista de Responsáveis -->
        <div class="responsaveis">
            <div class="responsavel">
                <h3>Vitor Almeida de Meira Santos </h3>
                <p>Função:Desenvovedor full-stack</p>
                <p>RGM:37948521</p>
                <p></p>
            </div>
            <div class="responsavel">
                <h3>Marcelo Júnior Nascimento Dos Santos
                </h3>
                <p>Função: Desenvolvedor Front-end </p>
                <p>RGM:38944014</p>
                <p></p>
            </div>
            <div class="responsavel">
                <h3>Davy Alexandre Curintima</h3>
                <p>Função: Desenvolvedor Front-and </p>
                <p>RGM:38548381</p>
                <p></p>
            </div>
            <div class="responsavel">
                <h3>Gustavo henrique Zamperlini de Queiroz 
                </h3>
                <p>Função: Desenvolvedor Back-and</p>
                <p>RGM:37833472</p>
                <p></p>
            </div>
            <div class="responsavel">
                <h3>Marcelo Fulanetti Ruiz Luz</h3>
                <p>Função: Desenvolvedor Full-stack</p>
                <p>RGM: 38090741</p>
                <p>Email: </p>
            </div>
            <div class="responsavel">
                <h3>Francisco Gustavo Gonzales Lopes Junior
                </h3>
                <p>Função: Idealista</p>
                <p>RGM: 37924583</p>
                <p>Email: </p>
            </div>
            <div class="responsavel">
                <h3>Luciano Roberto Joaquim</h3>
                <p>Função: Desenvolveor Full-stack</p>
                <p>RGM:38956586</p>
                <p></p>
            </div>
        </div>

        <!-- Formulário de Contato -->
        <h2>Envie uma Reclamação,Duvida ou Sugestão</h2>
        <form action="pgconb.php" method="POST">
            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="assunto">Assunto:</label>
            <input type="text" id="assunto" name="assunto" required>

            <label for="mensagem">Mensagem:</label>
            <textarea id="mensagem" name="mensagem" rows="5" required></textarea>

            <button type="submit">Enviar Mensagem</button>
        </form>
    </section>
</br>
   <!-- Rodapé -->
    <footer class="footer">
        <p>© 2024 Shows.Com. Todos os direitos reservados.</p>
    </footer> 
</body>
</html>
