<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Usuário - Shows.Com</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <header class="header">
        <h1>Login  de Usuário - Shows.Com</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="pgp.php">Show</a></li>
                <li><a href="pgcon.php">Contato</a></li>
                <li><a href="pglog.php">Login</a></li>
                <li><a href="pgsob.php">Sobre</a></li>
               
            </ul>
        </nav>
    </header>

    <section class="formulario-cadastro">
        <form method="POST" action="loginb.php">
            <h2>Login</h2>
            <h4>Nome:paulo</h4>
            <h5>Senha:12345</h5>

        <label for="usuario">Usuário:</label>
        <input type="text" name="usuario" id="usuario" required>
        <br><br>
        <label for="senha">Senha:</label>
        <input type="password" name="senha" id="senha" required>
        <br><br>
             <button type="submit" name="btn">Enviar</button>
        </form>
    </section>
       <!-- Rodapé -->
       <footer class="footer">
        <p>© 2024 Shows.Com. Todos os direitos reservados.</p>
    </footer> 
</body>
</html>

