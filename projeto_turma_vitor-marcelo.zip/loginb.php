<?php
 session_start()
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logado</title>
    <link rel="stylesheet" href="css/loginb.css">
</head>
<body>
 <div class="container">
   <?php
 

    // Nome de usuário e senha corretos
    $usuario_correto = "paulo";
    $senha_correta = "12345";

    // Captura os dados inseridos no formulário (POST)
    $usuario = $_POST['usuario'] ?? '';
    $senha = $_POST['senha'] ?? '';

    // Verifica se o formulário de login foi enviado
    if ($_SERVER["REQUEST_METHOD"] === "POST" && !isset($_POST['cancelar']) && !isset($_POST['enviar'])) {
        // Verifica se o nome de usuário e a senha estão corretos
        if ($usuario === $usuario_correto && $senha === $senha_correta) {
            $_SESSION['usuario_logado'] = $usuario; // Armazena o usuário na sessão
            echo "<h2>Acesso permitido. Bem-vindo, $usuario!</h2>";
        } else {
            echo "<p>Nome de usuário ou senha incorretos.</p>";
        }
    }

    // Verifica se o usuário está logado
    if (isset($_SESSION['usuario_logado'])) {
        // Botão para efetuar a compra
        echo '<form method="POST">';
        echo '<button type="submit" name="comprar">Comprar Ingresso</button>';
        echo '<button type="submit" name="deslogar">Deslogar</button>';
        echo '</form>';

        // Se o botão "Comprar Ingresso" foi clicado
        if (isset($_POST['comprar'])) {
            echo '<h3>Formulário de Venda de Ingresso</h3>';
            echo '<form method="POST">';
            echo '<label for="nome">Nome:</label>';
            echo '<input type="text" name="nome" required><br>';
            echo '<label for="email">Email:</label>';
            echo '<input type="email" name="email" required><br>';

            echo '<label for="idade">Idade:</label>';
            echo '<select name="idade" id="idade" required>';
            for ($i = 18; $i <= 100; $i++) {
                echo "<option value='$i'>$i</option>";
            }
            echo '</select><br>';

            echo '<label for="genero">Gênero:</label>';
            echo '<select name="genero" id="genero">';
            $generos = ["Masculino", "Feminino", "Outro", "Prefiro não dizer"];
            foreach ($generos as $genero) {
                echo "<option value='$genero'>$genero</option>";
            }
            echo '</select><br>';

            echo '<label for="tipo_ingresso">Tipo de Ingresso:</label>';
            echo '<select name="tipo_ingresso" id="tipo_ingresso" required onchange="toggleMeiaCategoria()">';
            echo '<option value="inteiro">Inteiro</option>';
            echo '<option value="meia">Meia-Entrada</option>';
            echo '</select><br>';

            echo '<div id="meia_categoria" style="display: none;">';
            echo '<label for="categoria_meia">Categoria:</label>';
            echo '<select name="categoria_meia" id="categoria_meia">';
            echo '<option value="estudante">Estudante</option>';
            echo '<option value="idoso">Idoso</option>';
            echo '<option value="professor">Professor</option>';
            echo '<option value="outro">Outro</option>';
            echo '</select></div>';

            echo '<label for="tipo_pista">Tipo de Pista:</label>';
            echo '<select name="tipo_pista" id="tipo_pista" required>';
            echo '<option value="premium">Pista Premium</option>';
            echo '<option value="pista">Pista</option>';
            echo '<option value="camarote">Camarote</option>';
            echo '</select><br>';

            echo '<button type="submit" name="enviar">Enviar</button>';
            echo '<button type="submit" name="cancelar">Cancelar Cadastro</button>';
            echo '</form>';
        }

        // Processa os dados do formulário de ingresso
        if (isset($_POST['enviar'])) {
            // Obtém e valida dados do formulário
            $nome = htmlspecialchars($_POST['nome']);
            $email = htmlspecialchars($_POST['email']);
            $idade = htmlspecialchars($_POST['idade']);
            $tipo_ingresso = htmlspecialchars($_POST['tipo_ingresso']);
            $categoria_meia = isset($_POST['categoria_meia']) ? htmlspecialchars($_POST['categoria_meia']) : null;
            $tipo_pista = htmlspecialchars($_POST['tipo_pista']);

            // Salva os dados na sessão para exibir a mensagem de boas-vindas posteriormente
            $_SESSION['nome_usuario'] = $nome;

            echo "<p>Compra efetuada com sucesso! Bem-vindo(a), $nome.</p>";
            echo "<p>Tipo de ingresso: $tipo_ingresso</p>";
            if ($tipo_ingresso == 'meia') {
                echo "<p>Categoria: $categoria_meia</p>";
            }
            echo "<p>Tipo de pista: $tipo_pista</p>";
    
        }

        // Deslogar
        if (isset($_POST['deslogar'])) {
            session_destroy();
            header("Location: index.php"); // Redireciona de volta para a página de login
            exit();
        }
    }
    ?>
</div>
    <script>
        function toggleMeiaCategoria() {
            const tipoIngresso = document.getElementById('tipo_ingresso').value;
            const meiaCategoria = document.getElementById('meia_categoria');
            meiaCategoria.style.display = tipoIngresso === 'meia' ? 'block' : 'none';
        }
    </script>
</body>
</html>

