<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobre Nós - Shows.Com</title>
    <link rel="stylesheet" href="css/pgsob.css">
</head>
<body>
    <!-- Cabeçalho -->
    <header class="header">
        <h1>Sobre Nós - Shows.Com</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="pgp.php">Shows</a></li>
                <li><a href="pgcon.php">Contato</a></li>
                <li><a href="pglog.php">Login</a></li>
                <li><a href="pgsob.php">Sobre</a></li>
               
            </ul>
        </nav>
    </header>

    <!-- Seção Sobre Nós -->
    <section class="sobre-nos">
        <div class="container">
            <h2>Nossa História</h2>
            <p>Shows.Com nasceu da paixão por conectar pessoas a experiências inesquecíveis de entretenimento ao vivo. Desde 2010, nossa missão é facilitar o acesso a eventos e oferecer um serviço de qualidade na venda de ingressos para shows, festivais e eventos culturais em todo o Brasil.</p>
            
            <h2>Missão</h2>
            <p>Oferecer uma plataforma fácil e segura para que fãs possam adquirir ingressos para eventos de forma rápida, garantindo experiências únicas e memórias inesquecíveis.</p>

            <h2>Visão</h2>
            <p>Ser líder no mercado de ingressos para shows e eventos no Brasil, reconhecida pela excelência no atendimento e pela inovação tecnológica no setor de entretenimento.</p>

            <h2>Valores</h2>
            <ul>
                <li><strong>Compromisso com o cliente:</strong> Priorizar a satisfação dos nossos clientes, oferecendo um serviço rápido e de qualidade.</li>
                <li><strong>Inovação:</strong> Investir em tecnologias para melhorar a experiência de compra e a segurança nas transações.</li>
                <li><strong>Transparência:</strong> Comunicar de forma clara e honesta todos os detalhes dos eventos e ingressos.</li>
                <li><strong>Excelência:</strong> Buscar continuamente a excelência em nossos serviços e operações.</li>
            </ul>
        </div>
    </section>

    <!-- Equipe -->
    <section class="equipe">
        <h2>Nossas Estruturas e Funções</h2>
        <div class="membros-equipe">
            <div class="membro">
                <h3> SESSION </h3>
                <p><strong>Função:session_start()</strong><P</p>
                <p>Inicia uma sessão PHP. A sessão é usada para armazenar e manter dados do usuário durante a navegação pelo site, como o nome de usuário após o login ou informações temporárias de uma compra.Esta localizado nas paginas de contato, shows e login. </p>
            </div>
            <div class="membro">
                <h3>SESSION</h3>
                <p><strong>Função:$_SESSION</strong></p>
                <p>Variável superglobal usada para armazenar informações específicas do usuário. Permite, por exemplo, guardar o nome do usuário após ele se cadastrar e exibir mensagens de boas-vindas personalizadas.
                </p>
            </div>
            <div class="membro">
                <h3>Estruturas de controle PHP</h3>
                <p><strong>Função:</strong>IF , ELSE IF,FOREACH</p>
                <p>If / else if: Condicionais que verificam se um dado está presente, como um botão de envio ou cancelamento do formulário de cadastro.Foreach: Itera sobre arrays, exibindo informações de shows e ingressos.</p>
            </div>
            <div class="membro">
                <h3>Estruturas de contole PHP</h3>
                <p><strong>Função:</strong>FOR,SWITCH,WHILE </p>
                <p>For: Usado para gerar opções de idade automaticamente no formulário.
                Switch: Alternativa condicional usada para escolher opções de gênero no formulário.
                While: Alternativa a for ou foreach, mas controlada por condição, aqui usada para exibir opções de gênero no formulário.
                </p>
            </div>
            <div class="membro">
                <h3>$_POST e $_SERVER</h3>
                <p><strong>Função:</strong>$_POST</p>
                <p>$_POST: Captura os dados enviados via método POST de um formulário, como nome, e-mail e mensagem no formulário de contato.
                </p>
            </div>
            <div class="membro">
                <h3>$_POST e $_SERVER</h3>
                <p><strong>Função:</strong>$_SERVER["REQUEST_METHOD"]</p>
                <p>Usado para verificar o tipo de requisição HTTP, permitindo executar certas operações apenas quando um formulário for submetidoS.</p>
            </div>
            <div class="membro">
                <h3>Funções de Redirecionamento </h3>
                <p><strong>Função:</strong>(header())</p>
                <p>Header("Location: page.php"): Redireciona o usuário para outra página após uma ação, como cancelamento de cadastro, interrompendo a execução atual.</p>
            </div>
        </div>
    </section>
</br>
</br>
</br>
</br>
</br>
</br>
</br>
</br>


    <!-- Rodapé -->
    <footer class="footer">
        <p>© 2024 Shows.Com. Todos os direitos reservados.</p>
    </footer>
</body>
</html>
