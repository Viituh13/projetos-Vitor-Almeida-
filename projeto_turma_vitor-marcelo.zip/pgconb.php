
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="css/conb.css">
</head>
<body>
<?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $nome = htmlspecialchars($_POST['nome']);
            $email = htmlspecialchars($_POST['email']);
            $assunto = htmlspecialchars($_POST['assunto']);
            $mensagem = htmlspecialchars($_POST['mensagem']);
            
            echo "<div class='mensagem-enviada'>";
            echo "<h3>Obrigado pelo contato, $nome!</h3>";
            echo "<p><strong>Assunto:</strong> $assunto</p>";
            echo "<p><strong>Mensagem:</strong> $mensagem</p>";
            echo "<p><strong>Email para resposta:</strong> $email</p>";
            echo "</div>";
        }
        ?>
<a href="pgcon.php"><button name="btn">Voltar</button></a>
</body>
</html>